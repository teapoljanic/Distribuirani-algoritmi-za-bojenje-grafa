import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;
import java.util.StringTokenizer;

public class Proces1 {
    private static final HashMap<Integer, Integer> selected = new HashMap<>();
    private static final LinkedList<Integer> neighbors = new LinkedList<>();
    private static final LinkedList<Integer> com_with = new LinkedList<>();
    private static int degree = 0;
    private static int myId;
    private static int numProc;
    private static Linker comm = null;
    private static Msg m;
    private static final HashMap<Integer, Integer> randomvrj = new HashMap<Integer, Integer>();


    private static final HashMap<Integer, Integer> eliminated = new HashMap<Integer, Integer>();


    public static void handleMessage(Msg msg) {

        if (msg.getTag().equals("random")) {
            StringTokenizer st = new StringTokenizer(msg.getMessage());
            int srcId = Integer.parseInt(st.nextToken());
            int boja = Integer.parseInt(st.nextToken());
            randomvrj.put(srcId, boja);
        } else if (msg.getTag().equals("sy")) {

            StringTokenizer st = new StringTokenizer(msg.getMessage());
            int srcId = Integer.parseInt(st.nextToken());
            selected.put(srcId, 1);
        } else if (msg.getTag().equals("ey")) {
            StringTokenizer st = new StringTokenizer(msg.getMessage());
            int srcId = Integer.parseInt(st.nextToken());
            eliminated.put(srcId, 1);
        }

    }

    public static void main(String[] args) {


        try {
            String baseName = args[0];
            myId = Integer.parseInt(args[1]);
            numProc = Integer.parseInt(args[2]);
            System.out.println(numProc);
            comm = new Linker(baseName, myId, numProc);
            neighbors.addAll(comm.neighbors);
            com_with.addAll(neighbors);
            degree = neighbors.size();
            Random rand = new Random();
            int runda = 1;
            String stanje = "out";
            while (true) {
                System.out.println("------------------runda: " + runda + "---------------------------");
                randomvrj.put(myId, rand.nextInt(1000));
                System.out.println(com_with);
                posalji_svima("random", myId + " " + randomvrj.get(myId));
                primi_svih();
                runda++;
                System.out.println("------------------runda: " + runda + "---------------------------");
                nis_odabrano();
                if (rand_svih_veci()) {
                    posalji_svima("sy", myId + " ");
                    stanje = "in";
                    System.out.println(stanje);
                    Thread.sleep(1000);
                    break;
                } else {
                    posalji_svima("sn", myId + " ");
                    primi_svih();
                }
                runda++;
                System.out.println("------------------runda: " + runda + "---------------------------");
                if (postoji_k()) {
                    posalji_svima_ostalima();
                    stanje = "out";
                    System.out.println(stanje);
                    Thread.sleep(1000);
                    break;
                } else {
                    posalji_svima("en", myId + " ");
                    primi_svih();
                    System.out.println(eliminated.toString());
                    izbaci_eliminirane();
                    if (com_with.isEmpty()) {
                        stanje = "in";
                        System.out.println(stanje);
                        Thread.sleep(1000);

                        break;
                    }
                }
                runda++;

            }

        } catch (Exception e) {
            System.err.println(e);
        }
    }

    private static void izbaci_eliminirane() {
        for (Integer j : neighbors)
            if (com_with.contains(j) && eliminated.get(j) == 1) com_with.remove(j);
    }

    private static void posalji_svima_ostalima() {
        for (Integer j : com_with)
            if (j != myId && selected.get(j) == 0) {

                comm.sendMsg(j, "ey", myId + " ");
            }
    }

    private static boolean
    postoji_k() {
        for (Integer j : com_with) if (selected.get(j) == 1) return true;
        return false;
    }


    private static boolean rand_svih_veci() {
        for (Integer j : com_with) {

            if (j != myId && randomvrj.get(j) <= randomvrj.get(myId)) return false;
        }
        return true;

    }

    private static void nis_odabrano() {
        for (Integer j : com_with) {
            if (j != myId) {
                selected.put(j, 0);
                eliminated.put(j, 0);
            }
        }
    }

    static void posalji_svima(String tag, String msg) {
        for (Integer j : com_with)
            if (j != myId) {
                try {
                    comm.sendMsg(j, tag, msg);
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
    }

    static void primi_svih() {
        for (Integer j : com_with)
            if (j != myId) {
                m = null;
                while (m == null) {
                    try {
                        m = comm.receiveMsg(j);
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
                handleMessage(m);
            }

    }


}