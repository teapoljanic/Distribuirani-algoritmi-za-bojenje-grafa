import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class Proces {
    private static final LinkedList<Integer> neighbors = new LinkedList<Integer>();
    private static final HashMap<Integer, Integer> colour = new HashMap<>();
    private static int degree = 0;
    private static int myId;
    private static int numProc;
    private static Linker comm = null;
    private static Msg m;
    private static HashMap<Integer, Boolean> selected = new HashMap<Integer, Boolean>();

    private static void initColour() throws IOException, InterruptedException {
        colour.put(myId, myId);
        for (int i = 0; i < numProc; i++) {
            if (i != myId && neighbors.contains(i)) {
                comm.sendMsg(i, "init_colour", myId + " " + myId);
            }
        }

        for (int i = 0; i < numProc; i++) {
            if (i != myId && neighbors.contains(i)) {
                m = comm.receiveMsg(i);

                handleMessage(m);
            }
        }
    }

    public static void init_selection() {
        for(Integer neighbor: neighbors){
            selected.put(neighbor,false);
        }
        selected.put(myId,false);

    }

    public static void findMaxDeegre() throws IOException {
        for (int i = 0; i < numProc; i++) {
            BufferedReader dIn = new BufferedReader(new FileReader("topology" + i));
            StringTokenizer st = new StringTokenizer(dIn.readLine());
            if (st.countTokens() > degree) degree = st.countTokens();

        }
    }

    public static void bojanje() throws InterruptedException {

        for (int ri = degree + 1; ri < numProc; ri++) {
            System.out.println("--------------------"+" runda "+ ri+"--------------------");
            if (colour.get(myId) == ri) {
                for (int i = 0; i < degree + 1; i++){
                        Boolean nemasus =nemaliSus(i);
                        if (nemasus) {
                            colour.put(myId, i);
                            break;
                        }
                }
            }

            for (int i = 0; i < numProc; i++) {
                if (i != myId && neighbors.contains(i)) {
                    comm.sendMsg(i, "bojanje", myId + " " + colour.get(myId));
                }
            }

            for (int i = 0; i < numProc; i++) {
                if (i != myId && neighbors.contains(i)) {
                    m = null;
                    while (m == null) {
                        m = comm.receiveMsg(i);
                        Thread.sleep(1000);
                    }
                    handleMessage(m);
                }
            }
        }
    }

    public static void maxindset() throws InterruptedException {
        for (int ri = 1; ri < numProc; ri++) {
            System.out.println("--------------------"+" runda "+ ri+"--------------------");
            if(colour.get(myId) == ri) {
                Boolean selectedi = true;
                for(int i = 0; i < numProc; i++) {
                    if (neighbors.contains(i) && selected.get(i)) {
                        selectedi = false;
                    }
                }
                if(selectedi) {
                    selected.put(myId, true);
                }
            }

            for (int i = 0; i < numProc; i++) {
                if (i != myId && neighbors.contains(i))
                    comm.sendMsg(i, "maxindset", myId + " " + selected.get(myId));
            }

            for (int i = 0; i < numProc; i++) {
                if (i != myId && neighbors.contains(i)) {
                    m = null;
                    while (m == null) {
                        m = comm.receiveMsg(i);
                        Thread.sleep(1000);
                    }
                    handleMessage(m);
                }
            }
        }
    }

    private static Boolean nemaliSus(int i) {
        if(i==myId) return false;
        for(Integer neighbor: neighbors){
            if (neighbor==myId) continue;
            if(colour.get(neighbor)==i)return false;
        }
        return true;
    }

    public static void handleMessage(Msg msg) {
        if (msg.getTag().equals("init_colour")) {
            StringTokenizer st = new StringTokenizer(msg.getMessage());
            int srcId = Integer.parseInt(st.nextToken());
            int boja = Integer.parseInt(st.nextToken());
            colour.put(srcId, boja);
        } else if (msg.getTag().equals("bojanje")) {
            StringTokenizer st = new StringTokenizer(msg.getMessage());
            int srcId = Integer.parseInt(st.nextToken());
            int boja = Integer.parseInt(st.nextToken());
            colour.put(srcId, boja);
        } else if (msg.getTag().equals("init_selection")) {
            StringTokenizer st = new StringTokenizer(msg.getMessage());
            int srcId = Integer.parseInt(st.nextToken());
            Boolean boja = Boolean.parseBoolean(st.nextToken());
            selected.put(srcId, boja);
        } else if (msg.getTag().equals("maxindset")) {
            StringTokenizer st = new StringTokenizer(msg.getMessage());
            int srcId = Integer.parseInt(st.nextToken());
            Boolean boja = Boolean.parseBoolean(st.nextToken());
            selected.put(srcId, boja);
        }
    }

    public static void main(String[] args) {
        try {
            String baseName = args[0];
            myId = Integer.parseInt(args[1]);
            numProc = Integer.parseInt(args[2]);
            System.out.println(numProc);
            comm = new Linker(baseName, myId, numProc);
            neighbors.addAll(comm.neighbors);
            degree = neighbors.size();
            findMaxDeegre();
            System.out.println(degree);
            initColour();
            System.out.println(colour);
            init_selection();
            System.out.println(selected);
            bojanje();
            System.out.println(colour);
            maxindset();
            System.out.println(selected);
            System.out.println(colour);
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}