import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class Linker {
    public LinkedList<Integer> neighbors = new LinkedList<Integer>();
    PrintWriter[] dataOut;
    BufferedReader[] dataIn;
    BufferedReader dIn;
    int myId, N;
    Connector connector;

    public Linker(String basename, int id, int numProc) throws Exception {
        myId = id;
        N = numProc;
        dataIn = new BufferedReader[numProc];
        dataOut = new PrintWriter[numProc];
        System.out.println("Linker created sa base name: " + basename + " id: " + id + " numProc: " + numProc);
        Topology.readNeighbors(myId, N, neighbors);

        Util.println(neighbors.toString());
        connector = new Connector();
        connector.Connect(basename, myId, numProc, dataIn, dataOut);
    }

    public void sendMsg(int destId, String tag, String msg) {
        System.out.println(myId + " šalje " + destId + " tag " + tag + " s porukom " + msg);
        dataOut[destId].println(myId + " " + destId + " " + tag + " " + msg + "#");

        dataOut[destId].flush();
    }

    public void sendMsg(int destId, String tag) {
        sendMsg(destId, tag, " 0 ");
    }

    public void multicast(LinkedList<Integer> destIds, String tag, String msg) {
        for (int i = 0; i < destIds.size(); i++) {
            sendMsg(destIds.get(i), tag, msg);
        }
    }

    public Msg receiveMsg(int fromId) throws InterruptedException {
        String getline = null;
        try {
            getline = dataIn[fromId].readLine();
            System.out.println("Recived Msg: " + getline);
            StringTokenizer st = new StringTokenizer(getline);
            int srcId = Integer.parseInt(st.nextToken());
            int destId = Integer.parseInt(st.nextToken());
            String tag = st.nextToken();

            String msg = st.nextToken("#");
            return new Msg(srcId, destId, tag, msg);


        } catch (IOException | NullPointerException e) {
            System.out.println("Nije stigla poruka od "+ fromId +" za "+ myId);
            return null;
        }


    }

    public int getMyId() {
        return myId;
    }

    public int getNumProc() {
        return N;
    }

    public void close() {
        connector.closeSockets();
    }
}
